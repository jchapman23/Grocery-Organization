/**
 * COM212 Data Structure
 * Queue implementation with SinglyLinkedList
 *
 * * ***NOTE***
 * This class has been edited to include 5 methods not originally included with the code:
 * remove(), print(), update(), code(), and clear()
 */

public class ListQueue<E> {
	
	private SinglyLinkedList<E> aList;
	
	public ListQueue() {
		aList = new SinglyLinkedList<E>();
	}
	
	public int size() { return aList.size(); }
	public boolean isEmpty() { return aList.isEmpty();}
	
	public void enqueue(E e, E k) {
		// add to the end of the list
		aList.addLast(e, k);
	}
	
	public void dequeue() {
		// empty?
		if (isEmpty()) {
			System.out.println("Error: queue is empty.");
		}
		aList.removeFirst();
	}
	
	public E first() {
		// empty?
		if (isEmpty()) {
			System.out.println("Error: queue is empty.");
			return null;
		}
		
		return aList.first();
	}
	/** This method calls the remove method added to the SLL class */
	public void remove(String str){
		aList.remove(str);
	}
	/** This method calls the printList method added to the SLL class */
	public void print(){
		aList.printList();
	}
	/** This method calls the updateKeys method added to the SLL class */
	public void update(int iter){
		aList.updateKeys(iter);
	}
	/** This method calls the ood method added to the SLL class */
	public void code(){
		aList.ood();
	}
	/** This method calls the clearzero method added to the SLL class */
	public void clear(){
		aList.clearzero();
	}
	
	public String toString() {
		
		// go over all elements
		if (isEmpty())
			return "The list is empty";
		
		String outstr = "Elements in the queue:\n";
		outstr = outstr + aList.toString();
				
		return outstr;	
	}
}