/**
 * COM212 Data Structure
 * Node class for general use
 *
 */

public class Node<E> {

    private E element;
    private E key;
	private Node<E> next;
	
	public Node () {
		element = null;
        next = null;
        key = null;
	}
	
	public Node(Node<E> n) {
		this();
		next = n;
	}
	
	public Node(E s) {
		this();
		element = s;
	}
	
	public Node(E s, E k) {
		this();
		element = s;
		key = k;
    }
	
	public Node(Node<E> n, E s, E k) {
        this();
		next = n;
		element = s;
		key = k;	
	}
	
	public Node<E> getNext() { return next;}
	public E getElement() { return element;}
	public E getKey() {return key;}
	
	public void setNext(Node<E> n) { next = n;}
	public void setElement(E e) { element = e;}
	public void setKey(E k) {key = k;}
	
	public String toString() { return element.toString();}
	
	public static void main(String[] args) {
		
	}
}