/**
 * COM212 Data Structure
 * SinglyLinkedList class
 *
 * ***NOTE***
 * This class has been edited to include 5 methods not originally included with the code:
 * remove(), printList(), updatekeys(), ood(), and clearzero()
 */

public class SinglyLinkedList<E> {

	
	private Node<E> head = null;
	private Node<E> tail = null;
	private int size = 0;
	
	public SinglyLinkedList() {
		// not much to do here!
	}
	
	public int size() { return size;}
	public boolean isEmpty() { return size == 0;}
	
	public E first() {
		if (isEmpty())
			return null;
		
		return head.getElement();
	}
	
	public E last() {
		if (isEmpty())
			return null;
		
		return tail.getElement();
	}
	
	public E getAt(int index) {
		
		// error check
		if (index >= size) {
			System.out.println("Error: index out of range");
			return null;
		}
			
		Node n = head;
		for (int i=0; i<index; i++) {
			n = n.getNext();
		}
		
		return (E)n.getElement();
	}
	
	public void addFirst(E s, E k) {
		Node<E> n = new Node<>(head, s, k);
		head = n;
		
		if (size==0)
			tail = n;
		
		size++;
	}
	
	public void addLast(E s, E k) {
		
		Node<E> n = new Node<>(s, k);
		
		if (size == 0){
			head = n;
		}
		else{
			tail.setNext(n);
		}
				
		tail = n;
			
		size++;
	}
	
	public void removeFirst() {
		
		if(isEmpty()){
			System.out.println("This list is empty!");
		}
		else{
			E s = head.getElement();
			head = head.getNext();
			size--;
			if(isEmpty()){tail = null;}
		}
	}
	/** This class was created to deal with removal of a node from the list at any given point
	 * It does so through a search the beginning of the list, looking for an element that
	 * matches the user input string
	 * It was implemented to allow for the sold() method in the grocery program
	 */
	public void remove(String str){

		if(isEmpty()){
			System.out.println("This list is empty!");
		}
		else{
			Node n = head;
			String stuff = String.valueOf(n.getElement());
			if (stuff.compareTo(str)==0){ //this if statement checks if the head is the searched for element
				head = n.getNext(); // sets the next node to be the new head
				size--; // decrements list size by one
				if(isEmpty()){tail = null;}
			}
			else{ //this else statement handles a linear search through the list
				Node temp = n.getNext();
				for (int i=1; i<size; i++){ // i starts at 1 since the head has already been checked
					String stuff2 = String.valueOf(temp.getElement()); 
					if (stuff2.compareTo(str)==0){ //if element is found
						n.setNext(temp.getNext()); //sets the previous node's 'next' variable to the the getNext() of the current node
						if (temp == tail){tail = n;} //sets a value for the tail if the tail is deleted
						size--;
						if(isEmpty()){tail = null;}
						break;
					}
					n = temp; //these two lines set the variables if the above loop does not find a matching element in the current iteration
					temp = temp.getNext();
				}
			}
		}
	}
	/** This method serves to print out the complete list */
	public void printList(){

		if(isEmpty()){
			System.out.println("This list is empty!");
		}
		else{
			Node n = head;
			for (int i=0; i<size; i++){
				System.out.println("        " + n.getKey() + ": " + n.getElement());
				n = n.getNext();
			}
		}
	}
	/** This method is unique to a SLL in the grocery program, as it is used to change the
	 * key values by a user determined iteration value
	 */
	public void updateKeys(int iter){
		Node n = head;
		for (int i=0; i<size; i++){
			String key = String.valueOf(n.getKey());
			int k = Integer.parseInt(key); //changes string to integer to perform numerical operation
			int sum = k + iter;
			String newKey = Integer.toString(sum);
			n.setKey(newKey);
			n = n.getNext();
		}
	}
	/** This method is also unique to the grocery program
	 * It loops through and checks if there are any nodes with key value 0
	 * Prints the key and element of any node with key 0
	 */
	public void ood(){
		if (isEmpty()) {
			System.out.println("Error: The list is empty.");
		}
		else{
			Node n = head;
			for (int i=0; i<size; i++){
				String key = String.valueOf(n.getKey());
				if (key.compareTo("0")<= 0){
					System.out.println("        " + n.getKey() + ": " + n.getElement());
					n = n.getNext();
				}
			}
		}
	}
	/** This method is also unique to the grocery program
	 * It serves to remove any nodes with key 0
	 * The main loop is broken if there are no more nodes left to test
	 * It breaks as soon as it encounters a non-zero key as well
	 */
	public void clearzero(){
		if (isEmpty()) {
			System.out.println("Error: The list is empty.");
		}
		boolean unclear = true;
		Node n = head;
		while(unclear){
			String key = String.valueOf(n.getKey());
				if (key.compareTo("0")<= 0){
					removeFirst();
					if (isEmpty()){
						unclear = false;
					}
				}
			else if(key.compareTo("0")> 0){
				unclear = false;
			}
			n = n.getNext();
		}
	}

	public String toString() {
		
		if (size == 0)
			return "The list is empty";
		
		String outstr = "";
		Node<E> n = head;	
		while (n != null) {
			outstr = outstr + n.getElement().toString() + "\n";
			n = n.getNext();
		} 
		return outstr;
	}
	
	public static void main(String[] args) {
		
	}
}