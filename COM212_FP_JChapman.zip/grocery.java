/**
* This prorgam serves the purpose of tracking the remaining days until
* an item of food is sold. It tracks by descending a key value that
* represents days remaining before out of date.
* A SLL Queue is used to store the data in a first in, last out fashion,
* and to more easily enable the removal of an item as it is sold
*
* @author  Josh Chapman
* @version 1.0
* @since   2020-12-5
*/

import java.util.StringTokenizer;
import java.util.Scanner;

public class grocery{

    /** Creates two new SLL queues to represent the shelf inventory of different departments */
    private ListQueue<String> bakery = new ListQueue();
    private ListQueue<String> deli = new ListQueue();
    
    /** this is the main method of the dictionary program */
    public void track(){
        /** Creates a scanner object to receive input from the user */
        Scanner scanner = new Scanner(System.in);

        /** creates a boolean variable to control the state of the while loop */
        boolean running = true;
        
        /** this while loop progresses the program through user input commands */
        while(running){
            System.out.print("Enter Command > ");

            String str = scanner.nextLine();

            /** Creates tokenizer object to parse through the input string, separating it by the blank spaces */
            StringTokenizer st = new StringTokenizer(str);

            String cmd = st.nextToken(); //sets variable cmd to the first word in the line of string

            /** These statements handle the entry of different commands from the user
             * 'insert' enacts the entry of an item into the queue of a department, along with the standard days to spoilage as its key
             * 'OOD' loops through the designated department's inventory, and prints a list of out of date items, which
             * are then removed from the inventory
             * 'inventory' prints the entire contents and days left to spoilage for the designated department
             * 'update' serves to advance the date by one day, moving the food a day closer to its spoil date
             * 'sold' serves to remove an item from the department inventory by searching for a match to the item name
             * 'quit' ends the program
             *  any other entry will return an error message
             *  failure to enter a valid department after certain commands will also return an error message
             */
            if(cmd.compareTo("insert")==0){
                String dept = st.nextToken();
                String value = "";
                while(st.hasMoreTokens()){
                    value = value + st.nextToken() + " ";
                }
                if (dept.compareTo("bakery")==0){
                    bakery.enqueue(value, "4"); // bakery items get a standard 5 days of shelf life, but the day it is inserted counts
                }
                else if (dept.compareTo("deli")==0){
                    deli.enqueue(value, "6"); // deli items get 7
                }
                else{
                    System.out.println("That is not a valid department, please try again.");
                }
            }
            else if(cmd.compareTo("OOD")==0){
                String dept = st.nextToken();
                System.out.println("result > current out of date items in "+dept+" :");
                if (dept.compareTo("bakery")==0){
                    bakery.code();
                    bakery.clear();
                }
                else if (dept.compareTo("deli")==0){
                    deli.code();
                    deli.clear();
                }
                else{
                    System.out.println("That is not a valid department, please try again.");
                }
            }
            else if(cmd.compareTo("inventory")==0){
                String dept = st.nextToken();
                if (dept.compareTo("bakery")==0){
                    bakery.print();
                }
                else if (dept.compareTo("deli")==0){
                    deli.print();
                }
                else{
                    System.out.println("That is not a valid department, please try again.");
                }
            }
            else if(cmd.compareTo("update")==0){
                bakery.update(-1);
                deli.update(-1);
            }
            else if(cmd.compareTo("sold")==0){
                String dept = st.nextToken();
                String value = "";
                while(st.hasMoreTokens()){
                    value = value + st.nextToken() + " ";
                }
                if (dept.compareTo("bakery")==0){
                    bakery.remove(value);
                    System.out.println("result > one "+value+" has been removed from inventory");
                }
                else if(dept.compareTo("deli")==0){
                    deli.remove(value);
                    System.out.println("result > one "+value+" has been removed from inventory");
                }
                else{
                    System.out.println("That is not a valid department, please try again.");
                }
            }
            else if(cmd.compareTo("quit")==0){
                System.out.print("Goodbye!");
                running = false;
            }
            else{
                System.out.println("This is not a valid command, please try again");
            }
        }
    }
}
/** test class */
class grocerytest{
    public static void main(String[] args){
        grocery test = new grocery();

        test.track();
    }
}